from pathlib import Path
from contextlib import closing
import sqlite3
from flask import Flask, jsonify, render_template, request


def create_app(database_path=None):
    app = Flask(__name__)
    app.config['DATABASE'] = str(database_path or Path(__file__).with_name('tasks.db'))
    with closing(sqlite3.connect(app.config['DATABASE'])) as db:
        db.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, title TEXT NOT NULL)')
        db.commit()

    @app.get('/')
    def index():
        return render_template('index.html')

    @app.get('/api/tasks')
    def get_tasks():
        with closing(sqlite3.connect(app.config['DATABASE'])) as db:
            rows = db.execute('SELECT id, title FROM tasks ORDER BY id').fetchall()
        return jsonify(items=[{'id': row[0], 'title': row[1]} for row in rows])

    @app.post('/api/tasks')
    def create_task():
        data = request.get_json(silent=True)
        title = data.get('title') if isinstance(data, dict) else None
        error_response = {'error': '任务标题不能为空'}
        if not isinstance(title, str) or not title.strip():
            return jsonify(error_response), 400
        title = title.strip()
        with closing(sqlite3.connect(app.config['DATABASE'])) as db:
            cursor = db.execute('INSERT INTO tasks (title) VALUES (?)', (title,))
            task_id = cursor.lastrowid
            db.commit()
        return jsonify(id=task_id, title=title), 201

    @app.get('/api/demo/error')
    def create_demo_error():
        raise ValueError('标题不能为空（报错演示）')

    return app


app = create_app()
