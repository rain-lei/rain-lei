import tempfile
import unittest
from pathlib import Path
from app import create_app


class TaskApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app(Path(self.temp.name) / 'tasks.db')
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp.cleanup()

    def test_normal_title_is_saved_and_listed(self):
        response = self.client.post('/api/tasks', json={'title': ' 学习 Git '})
        self.assertEqual(response.status_code, 201)
        data = response.get_json()
        self.assertEqual(data['title'], '学习 Git')
        self.assertIsInstance(data['id'], int)
        self.assertEqual(self.client.get('/api/tasks').get_json()['items'], [data])

    def test_empty_and_whitespace_do_not_create_tasks(self):
        for title in ['', '   ']:
            with self.subTest(title=title):
                response = self.client.post('/api/tasks', json={'title': title})
                self.assertEqual(response.status_code, 400)
                self.assertIn('error', response.get_json())
        self.assertEqual(self.client.get('/api/tasks').get_json()['items'], [])

    def test_invalid_payload_is_rejected(self):
        for payload in [{}, {'title': 123}, []]:
            with self.subTest(payload=payload):
                self.assertEqual(self.client.post('/api/tasks', json=payload).status_code, 400)


if __name__ == '__main__':
    unittest.main()
