# 任务清单：讲师演示项目

用于例会课件中的前后端请求、本地启动、标题校验和报错定位演示。

需要 Python 3.10 或更高版本。在本目录打开 Windows PowerShell：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m flask --app app run --debug --port 8000
```

打开 http://localhost:8000 ，输入“学习 Git”并保存。按 F12，进入 Network，选择 POST /api/tasks：

- Headers：请求地址、POST 方法、201 状态码。
- Payload：title 为“学习 Git”。
- Response：id 和 title。

空字符串和纯空格返回 400，并且不会保存任务。数据存入本地 tasks.db。

运行接口测试：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

访问 http://localhost:8000/api/demo/error 可触发用于演示的 ValueError。回到终端查看 app.py 中的 create_demo_error 和 raise 行。这个路由专门用于课堂演示。

Flask 的 debug 服务只用于本机演示。终止服务按 Ctrl+C。

macOS / Linux 可使用 python3 创建虚拟环境，后续将 .\.venv\Scripts\python.exe 替换为 .venv/bin/python。
